import { Component, OnInit } from '@angular/core';

import {Phrase} from '../Phrase';
import { PhraseService } from '../phrase.service';

@Component({
  selector: 'app-clauses',
  templateUrl: './clauses.component.html',
  styleUrls: ['./clauses.component.css']
})
export class ClausesComponent implements OnInit {
  clauses: Phrase[];

  constructor(private phraseService: PhraseService) { }

  ngOnInit() {
    this.getClauses();
  }

  getClauses(): void {
    this.phraseService.getClauses()
      .subscribe(clauses => this.clauses = clauses);
  }

  add(orig: string): void {
    orig = orig.trim();
    if (!orig) { return; }
    this.phraseService.addPhrase({ orig } as Phrase)
      .subscribe(phrase => {
        this.clauses.push(phrase);
      });
  }

  delete(phrase: Phrase): void {
    this.clauses = this.clauses.filter(h => h !== phrase);
    this.phraseService.deletePhrase(phrase).subscribe();
  }

}
