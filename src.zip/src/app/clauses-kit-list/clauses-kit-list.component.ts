import { Component, OnInit } from '@angular/core';
import {ClausesKit} from '../clauseskit';
import { ClausesKitService } from '../clauses-kit.service';

@Component({
  selector: 'app-clauses-kit-list',
  templateUrl: './clauses-kit-list.component.html',
  styleUrls: ['./clauses-kit-list.component.css']
})
export class ClausesKitListComponent implements OnInit {

  selectedClausesKit: ClausesKit;
  clausesKit: ClausesKit[];

  constructor(private clausesKitService: ClausesKitService) { }

  ngOnInit() {
    this.getClausesKit();
  }

  onSelect(clausesKit: ClausesKit): void {
    this.selectedClausesKit = clausesKit;
  }

  getClausesKit(): void {
    this.clausesKitService.getClausesKit()
      .subscribe(clausesKit => this.clausesKit = clausesKit);
  }

}
