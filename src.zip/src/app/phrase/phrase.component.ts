import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phrase',
  templateUrl: './phrase.component.html',
  styleUrls: ['./phrase.component.css']
})
export class PhraseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
