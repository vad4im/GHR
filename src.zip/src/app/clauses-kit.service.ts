import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { ClausesKit } from './clauseskit';
import { CLAUSES_KIT_LIST } from './mock-clauses-kit-list';
import { MessageService } from './message.service';

@Injectable({
  providedIn: 'root'
})
export class ClausesKitService {
  constructor(private messageService: MessageService) {}
  getClausesKit(): Observable<ClausesKit[]> {
    this.messageService.add ('PhraseService: fetched clausesKit');
    return of(CLAUSES_KIT_LIST);
  }
}
