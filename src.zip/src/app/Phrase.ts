export class Phrase  {
    id: number;
    orig: string;
    origTr: string;
    transl: string;
    translTr: string;
    origSound: string;
    translSound: string;
  }
