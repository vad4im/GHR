export class ClausesKit  {
  id: number;
  name: string;
  type: string;
  source: string;
}
