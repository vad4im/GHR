import { ClausesKit } from './clauseskit';

export const CLAUSES_KIT_LIST: ClausesKit[] = [
  { id: 1,  check: 0, name: 'custom',  source: 'hand made'},
  { id: 2,  check: 0, name: 'Short list',  source: 'Google'},
  ];
