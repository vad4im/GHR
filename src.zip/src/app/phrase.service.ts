import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Phrase } from './phrase';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({  providedIn: 'root'})
export class PhraseService {

  private clausesUrl = 'api/clauses';  // URL to web api

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }


getClauses(): Observable<Phrase[]> {
    return this.http.get<Phrase[]>(this.clausesUrl)
      .pipe(
        tap(clauses => this.log('fetched CLAUSES')),
        catchError(this.handleError('getClauses', []))
    );
  }
  searchClauses(term: string): Observable<Phrase[]> {
    if (!term.trim()) {
      // if not search term, return empty phrase array.
      return of([]);
    }
    return this.http.get<Phrase[]>(`${this.clausesUrl}/?orig=${term}`).pipe(
      tap(_ => this.log(`found clauses matching "${term}"`)),
      catchError(this.handleError<Phrase[]>('searchClauses', []))
    );
  }

  /** GET phrase by id. Will 404 if id not found */
  getPhrase(id: number): Observable<Phrase> {
    const url = `${this.clausesUrl}/${id}`;
    return this.http.get<Phrase>(url).pipe(
      tap(_ => this.log(`fetched phrase id=${id}`)),
      catchError(this.handleError<Phrase>(`getPhrase id=${id}`))
    );
  }

  /** POST: add a new phrase to the server */
  addPhrase (phrase: Phrase): Observable<Phrase> {
    return this.http.post<Phrase>(this.clausesUrl, phrase, httpOptions).pipe(
      tap((phrase2: Phrase) => this.log(`added phrase w/ id=${phrase2.id}`)),
      catchError(this.handleError<Phrase>('addPhrase'))
    );
  }

  /** PUT: update the phrase on the server */
  updatePhrase (phrase: Phrase): Observable<any> {
    return this.http.put(this.clausesUrl, phrase, httpOptions).pipe(
      tap(_ => this.log(`updated phrase id=${phrase.id}`)),
      catchError(this.handleError<any>('updatePhrase'))
    );
  }

  deletePhrase (phrase: Phrase | number): Observable<Phrase> {
    const id = typeof phrase === 'number' ? phrase : phrase.id;
    const url = `${this.clausesUrl}/${id}`;
    return this.http.delete<Phrase>(url, httpOptions).pipe(
      tap(_ => this.log(`deleted phrase id=${id}`)),
      catchError(this.handleError<Phrase>('deletePhrase'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /** Log a linguaService message with the MessageService */
  private log(message: string) {
    this.messageService.add(`LinguaService: ${message}`);
  }
}
